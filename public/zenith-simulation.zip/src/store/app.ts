import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type ViewName =
  | 'landing'
  | 'login'
  | 'register'
  | 'dashboard'
  | 'network-hub'
  | 'pulse'
  | 'operator-profile'
  | 'network-analysis'
  | 'doubt-chat'
  | 'proctored-sandbox'

interface AppState {
  currentView: ViewName
  user: {
    id: string
    name: string
    email: string
    role: string
    avatar?: string
    level: number
    status: string
  } | null
  sidebarCollapsed: boolean
  setView: (view: ViewName) => void
  setUser: (user: AppState['user']) => void
  logout: () => void
  toggleSidebar: () => void
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      currentView: 'landing',
      user: null,
      sidebarCollapsed: false,
      setView: (view) => set({ currentView: view }),
      setUser: (user) => set({ user, currentView: 'dashboard' }),
      logout: () => set({ user: null, currentView: 'landing' }),
      toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
    }),
    {
      name: 'zenith-app-store',
      storage: {
        getItem: (name) => {
          if (typeof window === 'undefined') return null
          const str = sessionStorage.getItem(name)
          return str ? JSON.parse(str) : null
        },
        setItem: (name, value) => {
          if (typeof window === 'undefined') return
          sessionStorage.setItem(name, JSON.stringify(value))
        },
        removeItem: (name) => {
          if (typeof window === 'undefined') return
          sessionStorage.removeItem(name)
        },
      },
      partialize: (state) => ({
        user: state.user,
        currentView: state.currentView,
      }),
    }
  )
)